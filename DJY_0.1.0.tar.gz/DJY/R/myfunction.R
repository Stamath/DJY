#' @title Say Hello
#'
#'@description Say hello to someone and give her/him an ID.
#'
#' @param name a \code{character} denoting the person to whom you plan to say hello.
#'
#' @return a \code{list} contain
#' @export
#'
#' @examples
#' myfunction("Batman")
myfunction=function(name="Poet"){
 id=round(runif(1,0,0.99),3)*1000
 print(paste0("Hello,",name,"Your ID is", id,"."))
 out=list(name=name,id=id)
 return(out)
}










