#' Poets
#'
#' A dataset containing information of 4 famous poets.
#'
#' @format A data frame with 4 rows and 2 variables
#' \describe{
#' \item{name}{name of the poet}
#' \item{born}{year of birth}
#' }
"mydata"
